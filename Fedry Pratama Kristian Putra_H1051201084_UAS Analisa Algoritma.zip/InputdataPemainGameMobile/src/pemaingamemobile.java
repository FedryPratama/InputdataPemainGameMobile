
public class pemaingamemobile {
	String name, id,jumlah;
	
	public pemaingamemobile (String name, String id, String jumlah) {
		this.name=name;
		this.id=id;
		this.jumlah=jumlah;
		
	}

}